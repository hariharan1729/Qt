
#include "ReqMsg.h"


void ReqMsg::setReqMsg(const QString &reqMsg)
{
    m_msg = reqMsg;
}
