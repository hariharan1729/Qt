#include <QObject>

class QNetworkReply;
class QXmlStreamReader;
class IRequestMessage;


class RequestMsgBuilder : public QObject
{
    Q_OBJECT

public:
    RequestMsgBuilder() {}

};
